# Ego Tree

[![crates.io](https://img.shields.io/crates/v/ego-tree?color=dark-green)][crate]
[![downloads](https://img.shields.io/crates/d/ego-tree)][crate]
[![test](https://github.com/rust-scraper/ego-tree/actions/workflows/test.yml/badge.svg)][tests]

Vec-backed ID-tree.

`ego-tree` is on [Crates.io][crate] and [GitHub][github].

[crate]: https://crates.io/crates/ego-tree
[github]: https://github.com/rust-scraper/ego-tree
[tests]: https://github.com/rust-scraper/ego-tree/actions/workflows/test.yml
