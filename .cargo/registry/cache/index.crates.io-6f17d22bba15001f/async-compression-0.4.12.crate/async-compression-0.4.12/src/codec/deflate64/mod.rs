mod decoder;

pub(crate) use self::decoder::Deflate64Decoder;
